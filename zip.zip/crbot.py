import config
import re
import time
from pyrogram import Client, filters
from binance.client import Client as cl

bot = config.bot
cli = cl(config.apiKey, config.apiSecret)
print("logged in")
app = config.app
app.start()
copyfrom = config.copyfrom
copyto = config.copyto


@app.on_message(filters.chat(copyfrom))
async def get_messages(client, message):
    start = time.time()
    final = 0

    if "1" == "1":
        file = open('config.txt', 'r').read().splitlines()
        # get_pair = [x for x in file if re.match(f"{x}", message.text)]
        # print(get_pair)
        names = []
        with open('symbols', 'r') as fp:
            for line in fp:
                x = line[:-1]
                names.append(x)

        gp = [c.split("|")[0] for c in names if re.search(
            f'(?i){c.split("|")[0]}|#{c.split("|")[0]}|{c.split("|")[1]}/{c.split("|")[2]}|#{c.split("|")[1]}/{c.split("|")[2]}',
        message.text)]
        try:
            pair = gp[0]
            if pair in file:
                if ("buy" in message.text or "BUY" in message.text or "long" in message.text or "LONG" in message.text or "Long" in message.text or "Buy" in message.text or "#LONG" in message.text) and config.buy is True:
                    # print(pair)
                    # await bot.send_message(copyto, message.text)
                    klines = cli.futures_historical_klines(pair, cli.KLINE_INTERVAL_1MINUTE, "3 minutes ago UTC")
                    klines2 = cli.futures_historical_klines(pair, cli.KLINE_INTERVAL_1MINUTE, "15 minutes ago UTC")
                    volume = sum(float(kline[5]) for kline in klines)
                    volume2 = sum(float(kline[5]) for kline in klines2)
                    result = volume / volume2 * 15 / 3
                    if config.end >= result >= config.start:
                        await buy(pair, start, result)
                    else:
                        print(f"TRADE WASN'T EXECUTED, THE VOLUME WAS %.2f" % result)
                    # await updater(pair)
                elif ("sell" in message.text or "SELL" in message.text or "short" in message.text or "SHORT" in message.text or "Short" in message.text or "Sell" in message.text or "#SHORT" in message.text) and config.sell is True:
                    # print(pair)
                    # await bot.send_message(copyto, message.text)
                    klines = cli.futures_historical_klines(pair, cli.KLINE_INTERVAL_1MINUTE, "3 minutes ago UTC")
                    klines2 = cli.futures_historical_klines(pair, cli.KLINE_INTERVAL_1MINUTE, "15 minutes ago UTC")
                    volume = sum(float(kline[5]) for kline in klines)
                    volume2 = sum(float(kline[5]) for kline in klines2)
                    result = volume / volume2 * 15 / 3
                    if config.end >= result >= config.start:
                        await sell(pair, start, result)
                    else:
                        print(f"TRADE WASN'T EXECUTED, THE VOLUME WAS %.2f" % result)
                    # await updater(pair)
                else:
                    # print("none")
                    return final
            else:
                print("BLACKLISTED PAIR")
        except IndexError:
            return final
    else:
        print("sorry")


async def sell(pair, start, result):
    cli.futures_change_leverage(symbol=pair, leverage=config.leverage)
    qtty, tickers, fll, price = quantitycal(symbol=pair, investment=config.investment)
    # print(qtty)
    num_a = tickers
    # print("QAUNTITY", qtty)
    order = cli.futures_create_order(
        symbol=f'{pair}',
        side='SELL',
        positionSide='SHORT',
        type='MARKET',
        quantity=qtty
        )
    try:
        currentOrder = cli.futures_get_order(symbol=pair, orderId=order['orderId'])
        # print(num_a)
        getn = str(currentOrder['avgPrice'])[::-1].find('.')
        vat = float(currentOrder['avgPrice']) + (float(currentOrder['avgPrice']) * config.sl / 100)
        sl = round(vat, fll)
        # print(sl)
        vat2 = float(currentOrder['avgPrice']) - (float(currentOrder['avgPrice']) * config.tp / 100)
        tp = round(vat2, fll)
        # print(tp)
        ## STOP LOSS
        buy_stop_market = cli.futures_create_order(
            symbol=pair,
            side='BUY',
            positionSide='SHORT',
            type='STOP_MARKET',
            stopPrice=sl,
            closePosition=True,
        )
        # print(buy_stop_market)
        ## TAKE PROFIT
        buy_gain_market = cli.futures_create_order(
            symbol=pair,
            side='BUY',
            positionSide='SHORT',
            type='TAKE_PROFIT_MARKET',
            stopPrice=tp,
            closePosition=True,
        )
        # print(buy_gain_market)
        print(f"NEW SIGNAL TRIGGERED -- SOLD/SHORTED {pair} @{tickers} with {config.investment} USDT -- VOLUME: %.2f" % result)
        end = time.time()
        print(f"It took {round(end - start, 1)} seconds to open this signal")
    except:
        # print(num_a)
        getn = str(price)[::-1].find('.')
        vat = float(price) + (float(price) * config.sl / 100)
        sl = round(vat, fll)
        # print(sl)
        vat2 = float(price) - (float(price) * config.tp / 100)
        tp = round(vat2, fll)
        # print(tp)
        ## STOP LOSS
        buy_stop_market = cli.futures_create_order(
            symbol=pair,
            side='BUY',
            positionSide='SHORT',
            type='STOP_MARKET',
            stopPrice=sl,
            closePosition=True,
        )
        # print(buy_stop_market)
        ## TAKE PROFIT
        buy_gain_market = cli.futures_create_order(
            symbol=pair,
            side='BUY',
            positionSide='SHORT',
            type='TAKE_PROFIT_MARKET',
            stopPrice=tp,
            closePosition=True,
        )
        # print(buy_gain_market)
        print(f"NEW SIGNAL TRIGGERED -- SOLD/SHORTED {pair} @{tickers} with {config.investment} USDT -- VOLUME: %.2f" % result)
        end = time.time()
        print(f"It took {round(end - start, 1)} seconds to open this signal")


# balance = cli.get_asset_balance(asset='BTC')
# balance2 = cli.get_asset_balance(asset='USDT')


# info = cli.get_account()
# print(info)
# print(balance)
# print(balance2)


async def buy(pair, start, result):
    cli.futures_change_leverage(symbol=pair, leverage=config.leverage)
    qtty, tickers, fll, price = quantitycal(symbol=pair, investment=config.investment)
    # print(qtty)
    num_a = tickers
    order = cli.futures_create_order(
        symbol=f'{pair}',
        side='BUY',
        positionSide='LONG',
        type='MARKET',
        quantity=qtty
    )
    try:
        currentOrder = cli.futures_get_order(symbol=pair, orderId=order['orderId'])
        # print(currentOrder)
        # print(num_a)
        getn = str(currentOrder['avgPrice'])[::-1].find('.')
        vat = float(currentOrder['avgPrice']) - (float(currentOrder['avgPrice']) * config.sl / 100)
        sl = round(vat, fll)
        # print(sl)
        vat2 = float(currentOrder['avgPrice']) + (float(currentOrder['avgPrice']) * config.tp / 100)
        tp = round(vat2, fll)
        # print(tp)
        # print(tp)
        ## STOP LOSS
        sell_stop_market = cli.futures_create_order(
            symbol=pair,
            side='SELL',
            positionSide='LONG',
            type='STOP_MARKET',
            stopPrice=sl,
            closePosition=True,
        )
        # print(sell_stop_market)
        # print(sell_stop_market)
        ## TAKE PROFIT
        sell_gain_market = cli.futures_create_order(
            symbol=pair,
            side='SELL',
            positionSide='LONG',
            type='TAKE_PROFIT_MARKET',
            stopPrice=tp,
            closePosition=True,
        )
        # print(sell_gain_market)
        print(f"NEW SIGNAL TRIGGERED -- BOUGHT/LONGED {pair} @{tickers} with {config.investment} USDT -- VOLUME: %.2f" % result)
        end = time.time()
        print(f"It took {round(end - start, 1)} seconds to open this signal")
    except:
        # print(currentOrder)
        # print(num_a)
        getn = str(price)[::-1].find('.')
        vat = float(price) - (float(price) * config.sl / 100)
        sl = round(vat, fll)
        # print(sl)
        vat2 = float(price) + (float(price) * config.tp / 100)
        tp = round(vat2, fll)
        # print(tp)
        # print(tp)
        ## STOP LOSS
        sell_stop_market = cli.futures_create_order(
            symbol=pair,
            side='SELL',
            positionSide='LONG',
            type='STOP_MARKET',
            stopPrice=sl,
            closePosition=True,
        )
        # print(sell_stop_market)
        # print(sell_stop_market)
        ## TAKE PROFIT
        sell_gain_market = cli.futures_create_order(
            symbol=pair,
            side='SELL',
            positionSide='LONG',
            type='TAKE_PROFIT_MARKET',
            stopPrice=tp,
            closePosition=True,
        )
        # print(sell_gain_market)
        print(f"NEW SIGNAL TRIGGERED -- BOUGHT/LONGED {pair} @{tickers} with {config.investment} USDT -- VOLUME: %.2f" % result)
        end = time.time()
        print(f"It took {round(end - start, 1)} seconds to open this signal")


def pricecalc(symbol, limit):
    raw_price = float(cli.get_symbol_ticker(symbol=symbol)['price'])
    dec_len = len(str(raw_price).split('.')[1])
    price = raw_price * limit
    return round(price, dec_len)


def rround(lotsize):
    splitted = str(lotsize).split('.')
    if float(splitted[0]) == 1:
        return 0
    else:
        return len(splitted[1])


def quantitycal(symbol, investment):
    info = cli.get_symbol_info(symbol=symbol)
    lotsize = float([i for i in info['filters'] if i['filterType'] == 'LOT_SIZE'][0]['minQty'])
    l = 0
    if symbol == 'BTCUSDT':
        price = float(cli.get_symbol_ticker(symbol=symbol)['price'])
        qty = round((investment / price)*0.97, 5)

    else:
        price = float(cli.get_symbol_ticker(symbol=symbol)['price'])
        qtty = round((investment / price)*0.97, rround(lotsize))
        rr = []
        with open('prc', 'r') as fp:
            for line in fp:
                x = line[:-1]
                rr.append(x)

        rr = [c.split("|")[2] for c in rr if c.split("|")[0] == symbol]
        l = int(rr[0])
        # print(l)
        pr = []
        with open('prc', 'r') as fp:
            for line in fp:
                x = line[:-1]
                pr.append(x)

        pr = [c.split("|")[1] for c in pr if c.split("|")[0] == symbol]
        s = int(pr[0])
        # print(s)
        # sss = float(round(qtty, s))
        if s == 0:
            try:
                qty = (str(qtty).split('.')[0])
            except IndexError:
                qty = qtty
        else:
            qty = float(round(qtty, s))
    return qty, price, l, price


# q, prr, l = quantitycal('RENUSDT', 5)
# print(f'Q is{q} PRR is {prr} L is {l}')
# symbol = 'ANKRUSDT'
# info = cli.futures_exchange_info()
# print("TASTAAA", sss)
# print("waataaan", s)
# requestedFutures = ['ANKRUSDT ']
#print(
#   {si['symbol']: si['quantityPrecision'] for si in info['symbols'] if si['symbol'] == symbol}
#)

#info = cli.futures_exchange_info()
#with open('prc', 'r') as f:
#    for si in info['symbols']:
#        f.write("%s|%s|%s\n" % (si['symbol'], si['quantityPrecision'], si['pricePrecision']))
#        print('done')


# requestedFutures = ['WAVESUSDT']
#print(
#    {si['symbol']: si['pricePrecision'] for si in info['symbols'] if si['symbol'] in requestedFutures}
#)


async def updater(pair):
    i = 0
    num_a = float(17813)
    while True:
        if i < 5:
            tickers = cli.get_symbol_ticker(symbol=pair)
            num_b = float(tickers["price"])
            numm = ((num_a - num_b) / num_b) * 100
            print(int(numm))
            print(tickers["price"])
            i += 1
            continue

        print("ok")
        break


print("Bot started")
bot.run()
